/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */
/***/ ((module) => {

module.exports = require("tslib");

/***/ }),
/* 2 */
/***/ ((module) => {

module.exports = require("express");

/***/ }),
/* 3 */
/***/ ((module) => {

module.exports = require("cors");

/***/ }),
/* 4 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.aotCompiler = exports.AotCompilerService = void 0;
const tslib_1 = __webpack_require__(1);
var aot_compiler_1 = __webpack_require__(5);
Object.defineProperty(exports, "AotCompilerService", ({ enumerable: true, get: function () { return aot_compiler_1.AotCompilerService; } }));
Object.defineProperty(exports, "aotCompiler", ({ enumerable: true, get: function () { return aot_compiler_1.aotCompiler; } }));
tslib_1.__exportStar(__webpack_require__(11), exports);


/***/ }),
/* 5 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


/**
 * Angular AOT Compiler Service
 *
 * Orchestrates the compilation process:
 * 1. Creates temporary project directory
 * 2. Writes Angular project files
 * 3. Spawns worker process to compile
 * 4. Collects results and cleans up
 */
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.aotCompiler = exports.AotCompilerService = void 0;
const tslib_1 = __webpack_require__(1);
const child_process_1 = __webpack_require__(6);
const fs = tslib_1.__importStar(__webpack_require__(7));
const path = tslib_1.__importStar(__webpack_require__(8));
const os = tslib_1.__importStar(__webpack_require__(9));
const crypto_1 = __webpack_require__(10);
const templates_1 = __webpack_require__(11);
const COMPILATION_TIMEOUT_MS = 10000; // 10 seconds
const MAX_INPUT_SIZE = 200 * 1024; // 200KB
class AotCompilerService {
    constructor() {
        // Worker path will be resolved at runtime
        this.workerPath = path.join(__dirname, 'compiler', 'worker.js');
    }
    /**
     * Validates the compilation request
     */
    validateRequest(request) {
        var _a;
        const diagnostics = [];
        if (!request || typeof request !== 'object' || Array.isArray(request))
            return [{ message: 'A JSON object is required', category: 'error' }];
        if (typeof request.componentTs !== 'string' || !request.componentTs.trim())
            diagnostics.push({ message: 'componentTs is required and must be a string', category: 'error' });
        for (const key of ['templateHtml', 'styleCss', 'angularVersionHint']) {
            if (request[key] !== undefined && typeof request[key] !== 'string')
                diagnostics.push({ message: `${key} must be a string`, category: 'error' });
        }
        if (diagnostics.length)
            return diagnostics;
        const complete = /@Component\s*\(/.test(request.componentTs);
        if (!complete && !((_a = request.templateHtml) === null || _a === void 0 ? void 0 : _a.trim()))
            diagnostics.push({ message: 'templateHtml is required for a component class body', category: 'error' });
        const size = Buffer.byteLength(request.componentTs + (request.templateHtml || '') + (request.styleCss || ''), 'utf8');
        if (size > MAX_INPUT_SIZE)
            diagnostics.push({ message: 'Source exceeds the 200 KB limit', category: 'error' });
        return diagnostics;
    }
    /**
     * Compiles Angular component source code
     */
    compile(request) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            // Validate request
            const validationErrors = this.validateRequest(request);
            if (validationErrors.length > 0) {
                return { ok: false, diagnostics: validationErrors };
            }
            const projectDir = path.join(os.tmpdir(), `ng-compile-${(0, crypto_1.randomUUID)()}`);
            try {
                // Create project structure
                yield this.createProjectStructure(projectDir, request);
                // Run compilation in worker process
                const result = yield this.runCompilation(projectDir);
                if (result.success) {
                    return {
                        ok: true,
                        files: result.files,
                        diagnostics: result.diagnostics,
                    };
                }
                else {
                    return { ok: false, diagnostics: result.diagnostics };
                }
            }
            catch (error) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                return {
                    ok: false,
                    diagnostics: [{ message: errorMessage, category: 'error' }],
                };
            }
            finally {
                // Always clean up temporary directory
                yield this.cleanup(projectDir);
            }
        });
    }
    /**
     * Creates the temporary Angular project structure
     */
    createProjectStructure(projectDir, request) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            const srcDir = path.join(projectDir, 'src');
            const appDir = path.join(srcDir, 'app');
            // Create directories
            fs.mkdirSync(appDir, { recursive: true });
            // Determine Angular version
            const angularVersion = '21';
            // Get the workspace node_modules path
            // In development, __dirname is in src/compiler, need to go up to workspace root
            // In production (bundled), __dirname is in dist/apps/angular-compiler-api
            let workspaceRoot = path.resolve(__dirname, '../../../../');
            let workspaceNodeModules = process.env.COMPILER_NODE_MODULES || path.join(__dirname, 'node_modules');
            if (!fs.existsSync(workspaceNodeModules))
                workspaceNodeModules = path.join(workspaceRoot, 'node_modules');
            // If that doesn't exist, try the production path
            if (!fs.existsSync(workspaceNodeModules)) {
                workspaceRoot = path.resolve(__dirname, '../../../');
                workspaceNodeModules = path.join(workspaceRoot, 'node_modules');
            }
            // Final fallback - look for node_modules relative to process.cwd()
            if (!fs.existsSync(workspaceNodeModules)) {
                workspaceNodeModules = path.join(process.cwd(), 'node_modules');
            }
            // Write tsconfig.json with the correct node_modules path
            fs.writeFileSync(path.join(projectDir, 'tsconfig.json'), (0, templates_1.getTsConfigJson)(workspaceNodeModules));
            // Write package.json
            fs.writeFileSync(path.join(projectDir, 'package.json'), (0, templates_1.getPackageJson)(angularVersion));
            // Write main.ts
            fs.writeFileSync(path.join(srcDir, 'main.ts'), (0, templates_1.getMainTs)(request.componentTs));
            // Write component file
            const hasStyles = !!request.styleCss;
            const isCompleteComponent = /@Component\s*\(/.test(request.componentTs);
            const componentContent = (0, templates_1.getComponentTs)(request.componentTs, !isCompleteComponent && !!request.templateHtml, hasStyles && !isCompleteComponent);
            fs.writeFileSync(path.join(appDir, 'demo.component.ts'), componentContent);
            // Write template file only if needed (not for complete components)
            if (request.templateHtml) {
                fs.writeFileSync(path.join(appDir, 'demo.component.html'), request.templateHtml);
            }
            // Write styles file only if provided and not a complete component
            if (request.styleCss) {
                fs.writeFileSync(path.join(appDir, 'demo.component.css'), request.styleCss);
            }
            // Create symlink to node_modules from workspace root
            // This is needed for the Angular compiler to resolve modules at runtime
            const tempNodeModules = path.join(projectDir, 'node_modules');
            try {
                // Try symlink first (faster, works on Windows with junction)
                fs.symlinkSync(workspaceNodeModules, tempNodeModules, 'junction');
            }
            catch (err) {
                // Fallback: compilation relies on tsconfig paths
                console.warn('Could not create symlink to node_modules:', err instanceof Error ? err.message : err);
            }
        });
    }
    /**
     * Runs compilation in a worker process with timeout
     */
    runCompilation(projectDir) {
        return new Promise((resolve) => {
            let worker = null;
            let timeoutId = null;
            let resolved = false;
            const cleanup = () => {
                if (timeoutId) {
                    clearTimeout(timeoutId);
                    timeoutId = null;
                }
                if (worker && !worker.killed) {
                    worker.kill('SIGKILL');
                }
            };
            try {
                // Resolve worker path - handle both development and production
                let workerPath = path.join(__dirname, 'compiler', 'worker.js');
                if (!fs.existsSync(workerPath)) {
                    workerPath = path.join(__dirname, 'worker.js');
                }
                worker = (0, child_process_1.fork)(workerPath, [], {
                    cwd: projectDir,
                    stdio: ['pipe', 'pipe', 'pipe', 'ipc'],
                    env: {
                        NODE_ENV: 'production',
                        NODE_OPTIONS: '--max-old-space-size=192',
                    },
                });
                // Set timeout
                timeoutId = setTimeout(() => {
                    if (!resolved) {
                        resolved = true;
                        cleanup();
                        resolve({
                            success: false,
                            files: [],
                            diagnostics: [
                                {
                                    message: `Compilation timed out after ${COMPILATION_TIMEOUT_MS}ms`,
                                    category: 'error',
                                },
                            ],
                        });
                    }
                }, COMPILATION_TIMEOUT_MS);
                worker.on('message', (message) => {
                    if (resolved)
                        return;
                    const msg = message;
                    if (msg.type === 'ready') {
                        // Worker is ready, send compile command
                        worker === null || worker === void 0 ? void 0 : worker.send({ type: 'compile', projectDir });
                    }
                    else if ('success' in msg) {
                        resolved = true;
                        cleanup();
                        resolve(msg);
                    }
                });
                worker.on('error', (error) => {
                    if (!resolved) {
                        resolved = true;
                        cleanup();
                        resolve({
                            success: false,
                            files: [],
                            diagnostics: [
                                { message: `Worker error: ${error.message}`, category: 'error' },
                            ],
                        });
                    }
                });
                worker.on('exit', (code) => {
                    if (!resolved) {
                        resolved = true;
                        cleanup();
                        resolve({
                            success: false,
                            files: [],
                            diagnostics: [
                                {
                                    message: `Worker exited unexpectedly with code ${code}`,
                                    category: 'error',
                                },
                            ],
                        });
                    }
                });
            }
            catch (error) {
                cleanup();
                const errorMessage = error instanceof Error ? error.message : String(error);
                resolve({
                    success: false,
                    files: [],
                    diagnostics: [{ message: errorMessage, category: 'error' }],
                });
            }
        });
    }
    /**
     * Cleans up temporary project directory
     */
    cleanup(projectDir) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            try {
                if (fs.existsSync(projectDir)) {
                    fs.rmSync(projectDir, { recursive: true, force: true });
                }
            }
            catch (error) {
                console.error(`Failed to cleanup ${projectDir}:`, error);
            }
        });
    }
}
exports.AotCompilerService = AotCompilerService;
// Export singleton instance
exports.aotCompiler = new AotCompilerService();


/***/ }),
/* 6 */
/***/ ((module) => {

module.exports = require("child_process");

/***/ }),
/* 7 */
/***/ ((module) => {

module.exports = require("fs");

/***/ }),
/* 8 */
/***/ ((module) => {

module.exports = require("path");

/***/ }),
/* 9 */
/***/ ((module) => {

module.exports = require("os");

/***/ }),
/* 10 */
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),
/* 11 */
/***/ ((__unused_webpack_module, exports) => {


/**
 * Templates for generating minimal Angular project files
 */
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getTsConfigJson = getTsConfigJson;
exports.getMainTs = getMainTs;
exports.getComponentTs = getComponentTs;
exports.getPackageJson = getPackageJson;
function getTsConfigJson(nodeModulesPath) {
    // Use forward slashes for paths in tsconfig
    const nmPath = nodeModulesPath.replace(/\\/g, '/');
    return JSON.stringify({
        compilerOptions: {
            baseUrl: '.',
            outDir: './dist',
            sourceMap: false,
            declaration: false,
            moduleResolution: 'node',
            emitDecoratorMetadata: true,
            experimentalDecorators: true,
            target: 'ES2022',
            module: 'ES2022',
            lib: ['ES2022', 'dom'],
            skipLibCheck: true,
            strict: false,
            noImplicitAny: false,
            noImplicitReturns: false,
            noFallthroughCasesInSwitch: false,
            useDefineForClassFields: false,
            forceConsistentCasingInFileNames: true,
            esModuleInterop: true,
            paths: {
                '@angular/*': [`${nmPath}/@angular/*`],
                'rxjs': [`${nmPath}/rxjs`],
                'rxjs/*': [`${nmPath}/rxjs/*`],
                'tslib': [`${nmPath}/tslib`],
                'zone.js': [`${nmPath}/zone.js`],
                'zone.js/*': [`${nmPath}/zone.js/*`],
            },
            types: [],
            typeRoots: [`${nmPath}/@types`],
        },
        angularCompilerOptions: {
            enableIvy: true,
            compilationMode: 'full',
            strictTemplates: false,
            strictInjectionParameters: false,
            strictInputAccessModifiers: false,
            flatModuleOutFile: null,
            strictNullInputBindings: false,
        },
        files: ['./src/main.ts', './src/app/demo.component.ts'],
    }, null, 2);
}
function getMainTs(source) {
    var _a;
    const name = /@Component\s*\(/.test(source) ? (_a = source.match(/export\s+class\s+([A-Za-z_$][\w$]*)/)) === null || _a === void 0 ? void 0 : _a[1] : 'DemoComponent';
    if (!name)
        throw new Error('Export a named standalone component class to compile.');
    return `import { bootstrapApplication } from '@angular/platform-browser';
import { ${name} } from './app/demo.component';

bootstrapApplication(${name}).catch(err => console.error(err));
`;
}
function getComponentTs(componentSource, hasTemplate, hasStyles) {
    // If user provides full component source, use it directly
    if (/@Component\s*\(/.test(componentSource)) {
        return componentSource;
    }
    // Otherwise, wrap in a minimal component
    const templateUrl = hasTemplate ? `templateUrl: './demo.component.html',` : '';
    const styleUrl = hasStyles ? `styleUrls: ['./demo.component.css'],` : '';
    return `import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-demo',
  standalone: true,
  imports: [CommonModule],
  ${templateUrl}
  ${styleUrl}
})
export class DemoComponent {
  ${componentSource}
}
`;
}
function getPackageJson(angularVersion) {
    return JSON.stringify({
        name: 'temp-angular-compile',
        version: '1.0.0',
        private: true,
        type: 'module',
        dependencies: {
            '@angular/core': `^${angularVersion}.0.0`,
            '@angular/common': `^${angularVersion}.0.0`,
            '@angular/compiler': `^${angularVersion}.0.0`,
            '@angular/compiler-cli': `^${angularVersion}.0.0`,
            '@angular/platform-browser': `^${angularVersion}.0.0`,
            rxjs: '^7.8.0',
            tslib: '^2.6.0',
            typescript: '^5.4.0',
            'zone.js': '^0.14.0',
        },
    }, null, 2);
}


/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;

/**
 * Angular Compiler API - Microservice
 *
 * Exposes HTTP endpoint to compile Angular components using AOT compilation.
 */
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(1);
const express_1 = tslib_1.__importDefault(__webpack_require__(2));
const cors_1 = tslib_1.__importDefault(__webpack_require__(3));
const compiler_1 = __webpack_require__(4);
const host = (_a = process.env.HOST) !== null && _a !== void 0 ? _a : 'localhost';
const port = process.env.PORT ? Number(process.env.PORT) : 3001;
const app = (0, express_1.default)();
// Security: Limit request body size to 200KB
app.use(express_1.default.json({ limit: '200kb' }));
// CORS: Only allow local development origin
const allowedOrigins = [
    'https://angular-compiler.giorgi.app',
    'http://localhost:4202',
    'http://127.0.0.1:4202',
    'http://localhost:4200',
    'http://localhost:4201',
    'http://127.0.0.1:4200',
];
app.use((0, cors_1.default)({
    origin: (origin, callback) => {
        // Allow requests with no origin (like curl)
        if (!origin) {
            callback(null, true);
            return;
        }
        if (allowedOrigins.includes(origin)) {
            callback(null, true);
        }
        else {
            callback(new Error('CORS not allowed'));
        }
    },
    methods: ['GET', 'POST', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
}));
// Health check endpoint
app.get('/health', (_req, res) => {
    res.json({
        status: 'healthy',
        service: 'angular-compiler-api',
        timestamp: new Date().toISOString(),
    });
});
// API info endpoint
app.get('/api', (_req, res) => {
    res.json({
        name: 'Angular Compiler API',
        version: '1.0.0',
        description: 'Compile Angular components using AOT compilation',
        endpoints: {
            'POST /api/compile': 'Compile Angular component source to Ivy output',
            'GET /health': 'Health check',
        },
    });
});
let compiling = false;
// Main compilation endpoint
app.post('/api/compile', (req, res) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c;
    if (compiling) {
        res.setHeader('Retry-After', '3');
        res.status(429).json({ ok: false, diagnostics: [{ message: 'The compiler is busy. Please retry in a few seconds.', category: 'error' }] });
        return;
    }
    compiling = true;
    try {
        const request = req.body;
        // Basic request validation
        if (!request || typeof request !== 'object') {
            const errorResponse = {
                ok: false,
                diagnostics: [
                    { message: 'Invalid request body', category: 'error' },
                ],
            };
            res.status(400).json(errorResponse);
            return;
        }
        // Log compilation request (without source code for security)
        console.log(`[${new Date().toISOString()}] Compilation request received - ` +
            `componentTs: ${((_a = request.componentTs) === null || _a === void 0 ? void 0 : _a.length) || 0} bytes, ` +
            `templateHtml: ${((_b = request.templateHtml) === null || _b === void 0 ? void 0 : _b.length) || 0} bytes, ` +
            `styleCss: ${((_c = request.styleCss) === null || _c === void 0 ? void 0 : _c.length) || 0} bytes`);
        // Compile the component
        const result = yield compiler_1.aotCompiler.compile(request);
        // Log result
        console.log(`[${new Date().toISOString()}] Compilation ${result.ok ? 'succeeded' : 'failed'} - ` +
            `files: ${result.ok ? result.files.length : 0}, ` +
            `diagnostics: ${result.diagnostics.length}`);
        res.json(result);
    }
    catch (error) {
        console.error('Compilation error:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        const errorResponse = {
            ok: false,
            diagnostics: [
                { message: `Server error: ${errorMessage}`, category: 'error' },
            ],
        };
        res.status(500).json(errorResponse);
    }
    finally {
        compiling = false;
    }
}));
// Error handling middleware
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err, _req, res, _next) => {
    console.error('Unhandled error:', err);
    if ('status' in err && err.status === 413) {
        res.status(413).json({ ok: false, diagnostics: [{ message: 'Source exceeds the 200 KB limit', category: 'error' }] });
        return;
    }
    // CORS error
    if (err.message === 'CORS not allowed') {
        res.status(403).json({
            ok: false,
            diagnostics: [{ message: 'CORS not allowed', category: 'error' }],
        });
        return;
    }
    // JSON parsing error
    if (err instanceof SyntaxError && 'body' in err) {
        res.status(400).json({
            ok: false,
            diagnostics: [{ message: 'Invalid JSON', category: 'error' }],
        });
        return;
    }
    // Generic error
    res.status(500).json({
        ok: false,
        diagnostics: [{ message: 'Internal server error', category: 'error' }],
    });
});
// Start server
app.listen(port, host, () => {
    console.log(`
╔═══════════════════════════════════════════════════════════╗
║         Angular Compiler API - Microservice               ║
╠═══════════════════════════════════════════════════════════╣
║  Status:  Ready                                           ║
║  URL:     http://${host}:${port}                              ║
║  Endpoints:                                               ║
║    POST /api/compile  - Compile Angular component         ║
║    GET  /api          - API information                   ║
║    GET  /health       - Health check                      ║
╚═══════════════════════════════════════════════════════════╝
  `);
});

})();

/******/ })()
;
//# sourceMappingURL=main.js.map