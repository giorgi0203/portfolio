/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */
/***/ ((module) => {

module.exports = require("tslib");

/***/ }),
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */
/***/ ((module) => {

module.exports = require("fs");

/***/ }),
/* 8 */
/***/ ((module) => {

module.exports = require("path");

/***/ }),
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */
/***/ ((module) => {

module.exports = require("typescript");

/***/ }),
/* 14 */
/***/ ((module) => {

module.exports = require("@angular/compiler-cli");

/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;

/**
 * Angular AOT Compiler Worker
 *
 * This module runs in a child process to compile Angular components
 * using the @angular/compiler-cli programmatic API.
 */
Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(1);
const fs = tslib_1.__importStar(__webpack_require__(7));
const path = tslib_1.__importStar(__webpack_require__(8));
const ts = tslib_1.__importStar(__webpack_require__(13));
function formatDiagnostic(diagnostic) {
    const message = ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n');
    let file;
    let line;
    let col;
    if (diagnostic.file && diagnostic.start !== undefined) {
        const { line: lineNum, character } = diagnostic.file.getLineAndCharacterOfPosition(diagnostic.start);
        file = path.basename(diagnostic.file.fileName);
        line = lineNum + 1;
        col = character + 1;
    }
    let category = 'error';
    if (diagnostic.category === ts.DiagnosticCategory.Warning) {
        category = 'warning';
    }
    else if (diagnostic.category === ts.DiagnosticCategory.Message ||
        diagnostic.category === ts.DiagnosticCategory.Suggestion) {
        category = 'info';
    }
    return { message, file, line, col, category };
}
function compile(projectDir) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const diagnostics = [];
        const files = [];
        try {
            // Dynamically import Angular compiler CLI
            const ngCompiler = yield Promise.resolve().then(() => tslib_1.__importStar(__webpack_require__(14)));
            const tsConfigPath = path.join(projectDir, 'tsconfig.json');
            // Read and parse tsconfig
            const configFile = ts.readConfigFile(tsConfigPath, ts.sys.readFile);
            if (configFile.error) {
                diagnostics.push(formatDiagnostic(configFile.error));
                return { success: false, files: [], diagnostics };
            }
            const parsedConfig = ts.parseJsonConfigFileContent(configFile.config, ts.sys, projectDir);
            if (parsedConfig.errors.length > 0) {
                for (const error of parsedConfig.errors) {
                    diagnostics.push(formatDiagnostic(error));
                }
                return { success: false, files: [], diagnostics };
            }
            // Configure Angular compiler options
            const angularCompilerOptions = Object.assign(Object.assign({}, parsedConfig.options), { enableIvy: true, compilationMode: 'full', strictTemplates: false, strictInjectionParameters: false, strictInputAccessModifiers: false, skipTemplateCodegen: false, flatModuleOutFile: undefined, declaration: false, declarationMap: false });
            // Read Angular compiler configuration
            const ngConfig = ngCompiler.readConfiguration(tsConfigPath);
            // Create Angular compiler host
            const host = ts.createCompilerHost(angularCompilerOptions);
            // Components may only read their temporary project and installed compiler libraries.
            const libraryRoot = fs.realpathSync(path.join(projectDir, 'node_modules'));
            const inside = (file) => {
                try {
                    const real = fs.realpathSync(file);
                    return [projectDir, libraryRoot].some(root => real === root || real.startsWith(root + path.sep));
                }
                catch (_a) {
                    return false;
                }
            };
            const read = host.readFile.bind(host), exists = host.fileExists.bind(host);
            host.readFile = file => inside(file) ? read(file) : undefined;
            host.fileExists = file => inside(file) && exists(file);
            // Store emitted files in memory
            const emittedFiles = new Map();
            const originalWriteFile = host.writeFile;
            host.writeFile = (fileName, data, writeByteOrderMark, onError, sourceFiles) => {
                const relativePath = path.relative(projectDir, fileName);
                emittedFiles.set(relativePath, data);
                // Also write to disk for Angular compiler
                if (originalWriteFile) {
                    originalWriteFile(fileName, data, writeByteOrderMark, onError, sourceFiles);
                }
            };
            // Create program using Angular's createProgram
            const program = ngCompiler.createProgram({
                rootNames: ngConfig.rootNames,
                options: Object.assign(Object.assign({}, ngConfig.options), angularCompilerOptions),
                host,
            });
            // Get all diagnostics
            const allDiagnostics = [
                ...program.getTsOptionDiagnostics(),
                ...program.getNgOptionDiagnostics(),
                ...program.getTsSyntacticDiagnostics(),
                ...program.getTsSemanticDiagnostics(),
                ...program.getNgSemanticDiagnostics(),
                ...program.getNgStructuralDiagnostics(),
            ];
            // Check for errors
            const errors = allDiagnostics.filter((d) => d.category === ts.DiagnosticCategory.Error);
            for (const diag of allDiagnostics) {
                diagnostics.push(formatDiagnostic(diag));
            }
            if (errors.length > 0) {
                return { success: false, files: [], diagnostics };
            }
            // Emit the compiled code
            const emitResult = program.emit();
            // Add emit diagnostics
            for (const diag of emitResult.diagnostics || []) {
                diagnostics.push(formatDiagnostic(diag));
            }
            if (emitResult.emitSkipped) {
                return { success: false, files: [], diagnostics };
            }
            // Collect emitted JS files
            for (const [filePath, content] of emittedFiles) {
                if (filePath.endsWith('.js') && !filePath.includes('node_modules')) {
                    files.push({ path: filePath, content });
                }
            }
            // Also read from dist directory if files weren't captured
            if (files.length === 0) {
                const distDir = path.join(projectDir, 'dist');
                if (fs.existsSync(distDir)) {
                    collectJsFiles(distDir, projectDir, files);
                }
            }
            return { success: true, files, diagnostics };
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            diagnostics.push({
                message: `Compilation error: ${errorMessage}`,
                category: 'error',
            });
            return { success: false, files: [], diagnostics };
        }
    });
}
function collectJsFiles(dir, baseDir, files) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
            collectJsFiles(fullPath, baseDir, files);
        }
        else if (entry.isFile() && entry.name.endsWith('.js')) {
            const relativePath = path.relative(baseDir, fullPath);
            const content = fs.readFileSync(fullPath, 'utf-8');
            files.push({ path: relativePath, content });
        }
    }
}
// Handle messages from parent process
process.on('message', (message) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    if (message.type === 'compile') {
        try {
            const result = yield compile(message.projectDir);
            if (process.send)
                process.send(result);
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            const result = {
                success: false,
                files: [],
                diagnostics: [{ message: errorMessage, category: 'error' }],
            };
            if (process.send)
                process.send(result);
        }
    }
}));
// Signal ready
if (process.send)
    process.send({ type: 'ready' });

})();

/******/ })()
;
//# sourceMappingURL=worker.js.map